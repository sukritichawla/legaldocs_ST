# Legal Docs Simplification Starter

This repo kickstarts the project.
